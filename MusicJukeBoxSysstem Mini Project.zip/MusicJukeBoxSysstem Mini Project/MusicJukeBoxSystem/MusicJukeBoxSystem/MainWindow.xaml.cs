﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;

namespace MusicJukeBoxSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDlg = new OpenFileDialog();
            Nullable<bool> result = openFileDlg.ShowDialog();
            if (result == true)
            {
                txtSearchSong.Text = openFileDlg.FileName;
            }
        }

        private void btnUpload_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                SqlCommand cmd = new SqlCommand();
                string filename;
                string full_file_name;
                full_file_name = txtSearchSong.Text;
                string[] names = full_file_name.Split(new Char[] { '\\' });
                filename = names.Last().ToString();

                SqlConnection con = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_19Sep18_Pune;User ID=sqluser;Password=sqluser");
                cmd.Connection = con;
                cmd.CommandText = "MusicJukeBox.MusicUpload";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("SongName", filename);
               // cmd.Parameters.AddWithValue("Content", SqlDbType.VarBinary).Value = File.ReadAllBytes(txtSearchSong.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Song Uploaded....");


            }
            catch (Exception) { throw; }
            
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
           
            DataTable dt = null;
            try
            {
                
                SqlConnection con = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_19Sep18_Pune;User ID=sqluser;Password=sqluser");
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand();
                cmd.CommandText = "MusicJukeBox.MusicDownload";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("SngId", Convert.ToInt32(txtSearchSong.Text));
                cmd.CommandType = CommandType.StoredProcedure;
                
                // cmd.Parameters.AddWithValue("Content", SqlDbType.VarBinary).Value = File.ReadAllBytes(txtSearchSong.Text);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    SaveFileDialog saveSong = new SaveFileDialog();
                    dt = new DataTable();
                    dt.Load(dr);
                }
                
                //saveSong.
                MessageBox.Show("Song Downloaded....");
            }
            catch (Exception) { throw; }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DataTable dt = null;
            SqlConnection con = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_19Sep18_Pune;User ID=sqluser;Password=sqluser");
            SqlCommand cmd = new SqlCommand();
            cmd = new SqlCommand();
            cmd.CommandText = "MusicJukeBox.MusicDisplay";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dt = new DataTable();
                dt.Load(dr);
            }
            if (dt != null)
            {
                dgDisplaySongs.ItemsSource = dt.DefaultView;
            }
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {

        }
    }
}
