﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;

namespace MusicJukeBoxSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDlg = new OpenFileDialog();
            Nullable<bool> result = openFileDlg.ShowDialog();
            // Get the selected file name and display in a TextBox.
            // Load content of file in a TextBlock
            if (result == true)
            {
                txtSearchSong.Text = openFileDlg.FileName;
            }
        }

        private void btnUpload_Click(object sender, RoutedEventArgs e)
        {
            try
            {
  
                string conStr = string.Empty;
                SqlConnection con = null;
                SqlCommand cmd = null;
                conStr = ConfigurationManager.ConnectionStrings["MusicJukeBoxSystem.Properties.Settings.ConStr"].ConnectionString;

                //FileStream file = new FileStream(txtSearchSong.Text, FileMode.Open);
                //byte[] songdata = new byte[file.Length];
                //file.Close();

                cmd = new SqlCommand();
                cmd.CommandText = "MusicJukeBox.MusicUpload";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;



                //cmd.Parameters.Add("@sId", SqlDbType.Int);
                //cmd.Parameters["@sId"].Direction = ParameterDirection.Output;

                cmd.Parameters.AddWithValue("@sname","baaad");


                con.Open();
                cmd.ExecuteNonQuery();

            }
            catch (Exception) { throw; }
            
        }
    }
}
