create schema MusicJukeBox

--============:Creating table Customer:=============
create table MusicJukeBox.Customer
(
CustKey int identity(1,1) primary key,
CustomerID  as 'C' + Right('000'+convert(varchar(5),CustKey),6)persisted not null,
CustomerName varchar(50)not null,
Address varchar(100)not null,
DOB datetime not null,
City varchar(20)not null,
Password varchar(20)not null,
MobileNo bigint not null
)

drop table MusicJukeBox.Songs

insert into MusicJukeBox.Customer values('egf','hgfhag',12/12/2018,'fdgh','fds',9878986755);

select * from MusicJukeBox.Customer



create table MusicJukeBox.Songs
(
SngId int identity(1,1) primary key,
SongName varchar(10) not null,
Singer varchar(100),
Movie varchar(50),
ComposedBy varchar(50),
Lyrics varchar(200),
ReleasedYear int ,
AlbumID varchar(20),
Language varchar(25)
) 

insert into MusicJukeBox.Songs(SongName) values('nilesh')

alter proc MusicJukeBox.MusicUpload(@mname varchar(10))
as
	begin
		insert into MusicJukeBox.Songs(SongName) values(@mname)
		
	end

 delete from tamal.Customer

 select * from MusicJukeBox.Songs

 alter proc tamal.LoginCust(@cid int,@pass varchar(15))
 as
 begin
  select count(*) from tamal.Customer where CustomerID=@cid and Password=@pass
  end





create table MusicJukeBox.MusicOrder
(
OrderID int primary key,
OrderDate datetime not null,
DeliveryDate datetime not null,
OrdPaymentID int not null,
Password varchar(20)not null,
MobileNo bigint not null
)